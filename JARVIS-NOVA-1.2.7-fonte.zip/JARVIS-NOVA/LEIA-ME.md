# J.A.R.V.I.S. Nova 1.2.9

Evolução baseada exclusivamente no fonte 1.2.5 fornecido. Mantém o aplicativo independente com `com.jarvis.nova`.

## Destaques desta revisão

- Detecção local openWakeWord com modelo “Hey Jarvis”, sem AccessKey de wake word.
- Mini-interface de ativação.
- Painel do celular com bateria, temperatura reportada pela bateria, armazenamento, RAM, conexão e atalhos do Android.
- Links oficiais para cadastrar chaves de IA; cotas gratuitas variam por provedor.
- Humor configurável (0–100%) e estilo de resposta equilibrado, formal, amigável ou técnico.
- Comando por voz para abrir a conversa WhatsApp de um contato cadastrado; envio de áudio e chamadas continuam sendo concluídos pelo usuário no WhatsApp.
- Atalhos para aplicativos comuns, mídia, tarefas, rotinas, alarmes e modo offline herdados da base 1.2.5.

## Gerar APK

Envie `JARVIS-NOVA-1.2.7-fonte.zip` para a raiz do repositório e faça commit na `main`. O workflow de Actions executará os testes, configurará a API mínima 26 e tentará compilar o APK. Consulte `CHECKLIST-PARA-GERAR-APK-1.2.7.md`.

## Limites e privacidade

O detector precisa analisar áudio local enquanto estiver habilitado; o indicador de microfone do Android pode permanecer ativo. O modelo atual reconhece “Hey Jarvis” em inglês, e a precisão em português precisa de teste físico. A licença do modelo pré-treinado é CC BY-NC-SA 4.0, portanto avalie-a antes de distribuir comercialmente. O Android não concede controle irrestrito de todos os apps; mensagens e chamadas continuam sujeitas a confirmação. Temperatura significa a leitura que o sistema reporta para a bateria.

## Estado real

Os testes estáticos passaram e o GitHub Actions já compilou uma versão debug 1.2.7. Esta revisão 1.2.9 integra o Porcupine, mantém fallback openWakeWord e revisa as configurações/persona; execute novamente o workflow para gerar o APK atualizado. Instalação e funcionamento em dispositivo físico ainda precisam ser verificados. O APK debug não equivale a uma versão de produção assinada para distribuição.


### Ajustes finais antes do APK

- A biblioteca de ativação local exige Android 8.0/API 26 ou superior; o patch Gradle agora aplica esse mínimo.
- Teste automatizado confirma que o patch da dependência e do repositório JitPack pode ser aplicado mais de uma vez sem duplicar entradas.
- A validação estática não substitui a compilação real nem o teste físico.

### Revisão 1.2.7

Inclui controles de humor/estilo e comando para abrir uma conversa WhatsApp com contato cadastrado. Ações de chamada, áudio e envio exigem revisão no próprio WhatsApp. Não equivale a controle irrestrito de aplicativos.

### Revisão 1.2.9

Consulte `RELATORIO-REVISAO-1.2.9.md` para a integração Porcupine, fallback openWakeWord e pendências. O nome do ZIP de fonte continua `JARVIS-NOVA-1.2.7-fonte.zip` para compatibilidade com o workflow; o app dentro dele é versão 1.2.9 (versionCode 1209).


## Segurança das chaves na versão 1.3.0
No Android, as chaves são cifradas com Android Keystore. No aplicativo desktop Electron, o `safeStorage` do sistema operacional cifra as chaves guardadas em arquivo privado do aplicativo. Se a criptografia do sistema não estiver disponível, o salvamento falha sem gravar em texto puro. O navegador comum não é recomendado para cadastrar chaves.

A AccessKey Picovoice é salva separadamente quando o campo perde o foco; o botão geral “Salvar ajustes” não é necessário para essa chave. Nunca compartilhe chaves em prints, mensagens ou repositórios.

A versão 1.3.0 ainda não contém uma integração funcional de modelo LLM local no Android. Essa etapa exige selecionar e validar um runtime/modelo compatível, medir RAM/temperatura e fazer build real antes de ser anunciada como disponível.
